package controller;

import domain.TabuleiroPassitosModel;
import view.DezPacitoView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

/**
 * 2ECOM.008 - LABORATÓRIO DE PROGRAMAÇÃO DE COMPUTADORES II - T05 (2021.1 - 5T12) - CEFET-MG.
 *
 * @author Lucas Siqueira Ribeiro. https://github.com/lucasdot
 * @author Pedro costa calazans. https://github.com/pedrocostacalazans
 * @author Pablo Vasconcelos da Cruz. https://github.com/Pablo321123
 * @version 1.0
 * Matriculas: 20203018919, 20203018697, 20203018801.
 */

public class CamposController implements ActionListener, MenuListener {

    private TabuleiroPassitosModel modelo;
    private DezPacitoView visao;

    public CamposController() {

    }

    public CamposController(TabuleiroPassitosModel modelo, DezPacitoView view) {
        this.modelo = modelo;
        this.visao = visao;

        modelo.preecherBombas();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() instanceof JButton) {
            AbstractButton button = (AbstractButton) e.getSource();
            //button.setEnabled(false);
            String[] posicao = button.getText().split(" ");

            modelo.verificaBomba(Integer.parseInt(posicao[0]), Integer.parseInt(posicao[1]));
            //System.out.println("i: " + posicao[0] + "\n" + "j: " + posicao[1]);
        }

    }

    @Override
    public void menuSelected(MenuEvent e) {
        if (e.getSource() instanceof JMenu) {
            JMenu menu = (JMenu) e.getSource();

            if (menu.getText().equals("Sair")) {
                modelo.sair();
            }

            if (menu.getText().equals("Reiniciar")) {
                modelo.reiniciar();
            }

        }
    }

    @Override
    public void menuDeselected(MenuEvent e) {

    }

    @Override
    public void menuCanceled(MenuEvent e) {

    }
}