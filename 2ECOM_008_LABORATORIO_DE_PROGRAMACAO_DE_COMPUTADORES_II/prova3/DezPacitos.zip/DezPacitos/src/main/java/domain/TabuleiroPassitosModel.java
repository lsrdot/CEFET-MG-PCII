package domain;

import javax.swing.*;
import java.util.Observable;
import java.util.Random;

/**
 * 2ECOM.008 - LABORATÓRIO DE PROGRAMAÇÃO DE COMPUTADORES II - T05 (2021.1 - 5T12) - CEFET-MG.
 *
 * @author Lucas Siqueira Ribeiro. https://github.com/lucasdot
 * @author Pedro costa calazans. https://github.com/pedrocostacalazans
 * @author Pablo Vasconcelos da Cruz. https://github.com/Pablo321123
 * @version 1.0
 * Matriculas: 20203018919, 20203018697, 20203018801.
 */

public class TabuleiroPassitosModel extends Observable {

    private Random rd = new Random();
    public final static int ROW = 7;
    public final static int COLUMNS = 12;
    private boolean tabuleiroBomba[][] = new boolean[ROW][COLUMNS], reiniciar = false;
    private int contador, vida = 10, pos_i, pos_j;


    public TabuleiroPassitosModel() {

    }

    public void preecherBombas() {
        for (int k = 0; k < ROW; k++) {
            for (int l = 0; l < COLUMNS; l++) {

                if (tabuleiroBomba[k][l]) {
                    continue;
                } else if (rd.nextBoolean()) {
                    tabuleiroBomba[k][l] = true;
                    contador++;
                }

                if (contador >= 60) {
                    break;
                }
            }
            if (contador >= 60) {
                break;
            }
        }
        if (contador < 60) {
            preecherBombas();
        }
    }

    public void verificaBomba(int i, int j) {
        if (tabuleiroBomba[i][j]) {
            System.out.println("Explodiu");
            pos_i = i;
            pos_j = j;
            vida--;
            setChanged();
            notifyObservers();
        }

        if(vida == 0){
            JOptionPane.showMessageDialog(null, "Suas vidas se esgotaram!\nPague 30 pontos no SIGAA mais proximo para recarrega-las", "Você perdeu!" ,JOptionPane.INFORMATION_MESSAGE);
        }

    }

    public void sair() {
        System.exit(0);
    }

    public int[] getCampoExplodido() {
        int campo_explodido[] = {pos_i, pos_j};
        return campo_explodido;
    }

    public void reiniciar() {
        tabuleiroBomba = new boolean[ROW][COLUMNS];
        preecherBombas();
        reiniciar = true;
        vida = 10;
        contador = 0;
        setChanged();
        notifyObservers();
    }

    public boolean getReiniciar() {
        return reiniciar;
    }

    public void setReiniciar(boolean reiniciar) {
        this.reiniciar = reiniciar;
    }

}
