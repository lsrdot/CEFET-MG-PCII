/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Observable;
import java.util.Observer;

import javax.imageio.ImageIO;
import javax.swing.*;

import controller.CamposController;
import domain.TabuleiroPassitosModel;

/**
 * 2ECOM.008 - LABORATÓRIO DE PROGRAMAÇÃO DE COMPUTADORES II - T05 (2021.1 - 5T12) - CEFET-MG.
 *
 * @author Lucas Siqueira Ribeiro. https://github.com/lucasdot
 * @author Pedro costa calazans. https://github.com/pedrocostacalazans
 * @author Pablo Vasconcelos da Cruz. https://github.com/Pablo321123
 * @version 1.0
 * Matriculas: 20203018919, 20203018697, 20203018801.
 */

public class DezPacitoView extends javax.swing.JFrame implements Observer {

    /**
     * Creates new form DezPacitoView
     */

    public DezPacitoView() {
    }

    public DezPacitoView(TabuleiroPassitosModel modelo) {
        this.modelo = modelo;
        control = criarControlador();
        initComponents();
        modelo.addObserver(this);
    }

    private CamposController criarControlador() {
        return new CamposController(modelo, this);
    }

    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        menuReiniciar = new JMenu();
        btCamps = new JButton[TabuleiroPassitosModel.ROW][TabuleiroPassitosModel.COLUMNS];

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 0, 51));
        jPanel1.setLayout(new java.awt.GridLayout(7, 12, 10, 10));

        File img = new File("img/bomba.png");
        // URL url = getClass().getResource(img.getPath());

        for (int i = 0; i < TabuleiroPassitosModel.ROW; i++) {
            for (int j = 0; j < TabuleiroPassitosModel.COLUMNS; j++) {
                btCamps[i][j] = new JButton();
                btCamps[i][j].addActionListener(control);
                btCamps[i][j].setFocusable(false);
                btCamps[i][j].setText(i + " " + j);
                btCamps[i][j].setForeground(new java.awt.Color(0, 0, 0, 0));
                btCamps[i][j].setBackground(Color.WHITE);
                //btCamps[i][j].setIcon();
                //btCamps[i][j].setDisabledIcon(new ImageIcon(getClass().getResource("/img/bomba.png")));
                jPanel1.add(btCamps[i][j]);
            }
        }

        jMenu1.setText("Menu");
        jMenuBar1.add(jMenu1);


        menuReiniciar.setText("Reiniciar");
        jMenu1.add(menuReiniciar);
        menuReiniciar.addMenuListener(control);

        jMenu2.setText("Sair");
        jMenu2.addMenuListener(control);
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup().addComponent(jPanel1,
                                javax.swing.GroupLayout.PREFERRED_SIZE, 565, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup().addComponent(jPanel1,
                                javax.swing.GroupLayout.PREFERRED_SIZE, 405, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)));

        pack();
    }

    // Variables declaration - do not modify                     
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu menuReiniciar;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private JButton[][] btCamps;
    private CamposController control;
    private TabuleiroPassitosModel modelo;

    protected ImageIcon createImageIcon(String path) {
        java.net.URL imgURL = getClass().getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }

    @Override
    public void update(Observable o, Object arg) {

        if (modelo.getReiniciar()) {
            for (int i = 0; i < TabuleiroPassitosModel.ROW; i++) {
                for (int j = 0; j < TabuleiroPassitosModel.COLUMNS; j++) {
                    btCamps[i][j].setBackground(Color.WHITE);
                    btCamps[i][j].setEnabled(true);
                }
            }
            modelo.setReiniciar(false);
            return;
        }

        int[] campo_explodido = modelo.getCampoExplodido();

        btCamps[campo_explodido[0]][campo_explodido[1]].setBackground(Color.black);
        btCamps[campo_explodido[0]][campo_explodido[1]].setEnabled(false);

    }


}
